public class InvalidKgException extends Exception
{
    public InvalidKgException(String message) {
        super(message);
    }
}
